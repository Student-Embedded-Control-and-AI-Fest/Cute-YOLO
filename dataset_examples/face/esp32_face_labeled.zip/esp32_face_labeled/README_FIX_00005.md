# Manual label correction

Updated one file based on the user's manually drawn red rectangles:

- `esp32_00005_20260822_160301_385491.jpg`

The corrected `labels/esp32_00005_20260822_160301_385491.txt` contains 9 face boxes in original 320x240 YOLO coordinates.
This ZIP remains drop-in compatible with the V8 notebook because labels are still original-camera-coordinate labels.
